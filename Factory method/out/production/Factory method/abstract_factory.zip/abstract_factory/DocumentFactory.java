package abstract_factory;

public interface DocumentFactory {
    Document createDocument();
}
