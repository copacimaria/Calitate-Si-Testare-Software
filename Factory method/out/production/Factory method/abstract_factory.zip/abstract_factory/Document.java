package abstract_factory;

public interface Document {
    void open();
    void save();
}
